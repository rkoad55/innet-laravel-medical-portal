@extends('layouts.app2')

@section('content')

@endsection