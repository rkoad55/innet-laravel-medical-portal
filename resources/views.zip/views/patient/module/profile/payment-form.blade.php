
            <div class="card card-danger  card-outline">
                <div class="card-header">
                <h3 class="card-title">Payment Information</h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                </div>
              </div>
              <div class="card-body">
                <form role="form" id="form4" novalidate="novalidate">
                    <!-- ------------------------------------------------------------------------------------------- -->
                    <div class="row">
                        <div class="form-group col-6 required">
                            <label for="name" clas="required">Card Number<span class="text-danger">*</span></label>
                            <!-- <input type="text" class="form-control" name="creditcard" data-inputmask-alias="creditcard" value="" data-inputmask-inputformat="1234 1234 1234 1234" data-mask> -->
                            <input type="text" class="form-control" data-inputmask='"mask": "9999-9999-9999"' data-mask>
                            
                        </div>
                        <div class="form-group col-6">
                            <label for="text" clas="required">CVV<span class="text-danger">*</span></label>
                            <input type="password" name="cvv"  class="form-control" id="cvv" data-inputmask='"mask": "999"' data-mask>
                        </div>
                    </div>
                    <!-- ------------------------------------------------------------------------------------------- -->
                    
                   
                    
                    <!-- ------------------------------------------------------------------------------------------- -->
                    <div class="form-group mb-0">
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" name="terms" class="custom-control-input" id="exampleCheck1">
                      <label class="custom-control-label" for="exampleCheck1">I agree to the <a href="#">terms of service</a>.</label>
                    </div>
                  </div>  
                    
                    
                    <div class="row">
                        <div class="col-md-12">
                          <div class="alert alert-success alert-dismissible hide" id="success-alert_payment">
                            Your Information has been Updated.
                          </div>
                        </div>
                      </div>
                  <!-- ------------------------------------------------------------------------------------------- -->
                
                </div>
                <div class="card-footer">
                  <button type="submit" id="submitbutton_loading_payment" name="submit" class="btn btn-danger">Submit</button>
                  <span class="hide" id="loading_payment"><i class="fa fa-spinner fa-pulse fa fa-fw"></i><span class="sr-only">Loading...</span></span>
                </div>
              </form>
            </div>



<script type="text/javascript">
$(document).ready(function(){
	$('#submitbutton_loading_payment').click(function() {
 			$("#form4").validate({
        rules:{
          creditcard: {required: true},  
          cvv: {required: true},  
      },

      messages: {
        creditcard: "Enter Your Credit Card Number",
        cvv: "Enter Your CVV number",
      },

      errorElement: 'span',
      errorPlacement: function (error, element) {
        error.addClass('invalid-feedback');
        element.closest('.form-group').append(error);
      },
      highlight: function (element, errorClass, validClass) {
        $(element).addClass('is-invalid');
      },
      unhighlight: function (element, errorClass, validClass) {
        $(element).removeClass('is-invalid');
      },
			submitHandler:function(form){
        //var fdata=new FormData(form);
        $('#loading_payment').removeClass('hide').show();

				var fdata=new FormData(form);
				$.ajax({
					type: "POST",
					url: '{{route("patient.payment")}}',
					data: fdata,
					contentType: false,
					cache: false,
					processData:false,
					success: function(result)
					{
            console.log(result);
            if(result == 1){
              $('#loading_payment').addClass('hide').hide();
              // $('#success-alert_payment').removeClass('hide').show().slideDown(500).delay(2500).slideUp(500);
              $('#success-alert_payment').removeClass('hide').show().html(result);

            }
						return false;
					}
				});
				
				return false;
			}
        });
        });

	
});

   

</script>
 